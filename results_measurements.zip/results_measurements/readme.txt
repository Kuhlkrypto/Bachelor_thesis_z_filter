This directory contains results of the measurement for precision, fitness, simplicity and generality in terms of model quality
and so called referenced model quality which is measured by using the original event log for assessing the quality dimensions of
filtered process models (process models discovered form filtered event logs).

-----------------------------------------------------------------------
The subdirectory `plotted_graphic_measurements` in particular contains the values used for plotting the
graphics in the paper for this Bachelor thesis and more.

The directory 'model quality' in particular contains extra measurements assessing the model quality of generalized event logs.
Rows containing an entry with z=0 and dt = base refer to the original process model.
The quality of original process models is often stored in the plotted_graphics_measurement.
The value dt=0 refers to infinity, every other value refers to the time window in seconds.

The last subdirectory contains some measurements regarding event logs with not generalized timestamps.
However, they are not as precise as others because this worked focused on generalized logs later on.


All fitness and precision measurement in this directory have been performed using the alignment methods of pm4py.
The tbr method results are excluded as their implementation don't seem to follow the papers they are described in.
----------------------------------------------------------------